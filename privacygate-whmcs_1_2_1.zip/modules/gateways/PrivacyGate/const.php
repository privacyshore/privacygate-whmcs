<?php
defined('METADATA_CLIENT_PARAM') or  define('METADATA_CLIENT_PARAM', 'clientid');
defined('METADATA_INVOICE_PARAM') or  define('METADATA_INVOICE_PARAM', 'invoiceid');
defined('METADATA_SOURCE_PARAM') or  define('METADATA_SOURCE_PARAM', 'source');
defined('METADATA_SOURCE_VALUE') or define('METADATA_SOURCE_VALUE', 'whmcs');
defined('SIGNATURE_HEADER') or define('SIGNATURE_HEADER', 'x-cc-webhook-signature');

